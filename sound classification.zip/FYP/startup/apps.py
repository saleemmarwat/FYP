from django.apps import AppConfig


class StartupConfig(AppConfig):
    name = 'startup'
