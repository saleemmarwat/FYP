from django.db import models

class admin(models.Model):
    user_name = models.CharField(max_length=30)
    user_email = models.CharField(max_length=250)
    user_password = models.CharField(max_length=8)

class audioFile(models.Model):
    file_name = models.CharField(max_length=250)
    file_dest = models.CharField(max_length=250)
