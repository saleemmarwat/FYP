from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from startup.models import admin, audioFile
import os
from django.core.files.base import ContentFile
import librosa 
from scipy.io import wavfile as wav
import numpy as np
import matplotlib.pyplot as plt
import io
import urllib, base64

def startup(request):
    return render(request, 'startup/startup.html', {})

def login(request):
    if request.method == "POST":
        username=request.POST['user']
        password=request.POST['pass']
        user = admin.objects.filter(user_name=username, user_password=password).exists()
        if user:
            request.session['authenticated'] = username
            return render(request, 'startup/dashboard.html',{})
        else:
            return render(request, 'startup/startup.html',{"error":"404"})

def logout(request):
    del request.session['authenticated']
    return render(request, 'startup/startup.html',{})

def upload_data(request):
    if request.method == "POST":
        folder = 'Fold0\\' #request.path.replace("/", "_")
        uploaded_filename = request.FILES['datafile'].name
        BASE_PATH = 'D:\\FYP\\startup\\static\\startup'

        # save the uploaded file inside that folder.
        full_filename = os.path.join(BASE_PATH, folder, uploaded_filename)
        fout = open(full_filename, 'wb+')

        file_content = ContentFile(request.FILES['datafile'].read())
        for chunk in file_content.chunks():
            fout.write(chunk)
        fout.close()
        audioFile.objects.create(file_name=uploaded_filename, file_dest=full_filename)
    return render(request, 'startup/dashboard.html',{"dataUpload":"success"})

def auditory_inspection(request):
    tempAudioFlieList = audioFile.objects.all()
    audioFileList = []
    for audioFileTemp in tempAudioFlieList:
        audioFileList.append([audioFileTemp.file_name, audioFileTemp.file_dest])
    return render(request, 'startup/dashboard.html', {"AIaudioFileList":audioFileList})

def visual_inspection(request):
    tempAudioFlieList = audioFile.objects.all()
    audioFileList = []
    for audioFileTemp in tempAudioFlieList:
        audioFileList.append([audioFileTemp.file_name, audioFileTemp.file_dest])
    return render(request, 'startup/dashboard.html', {"VIaudioFileList":audioFileList})

def convert_fig_to_uri(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format='png')
    buf.seek(0)
    string = base64.b64encode(buf.read())
    uri = urllib.parse.quote(string)
    return uri

def get_full_path(aFile):
    folder = 'Fold0\\'
    BASE_PATH = 'D:\\FYP\\startup\\static\\startup'
    filename = os.path.join(BASE_PATH, folder, aFile)
    return filename

def original_waveform(request):
    aFile = request.GET['file']
    filename = get_full_path(aFile)
    scipy_sample_rate1, scipy_audio1 = wav.read(filename)
    # Original audio with 2 channels 
    plt.plot(scipy_audio1)
    fig = plt.gcf()
    uri = convert_fig_to_uri(fig)
    return JsonResponse(uri, safe=False)

    
def librosa_waveform(request):
    aFile = request.GET['file']
    filename = get_full_path(aFile)
    librosa_audio2, librosa_sample_rate2 = librosa.load(filename) 
    # Librosa audio with channels merged 
    plt.plot(librosa_audio2)
    fig = plt.gcf()
    uri = convert_fig_to_uri(fig)
    return JsonResponse(uri, safe=False)

def spectogram(request):
    aFile = request.GET['file']
    filename = get_full_path(aFile)
    librosa_audio3, librosa_sample_rate3 = librosa.load(filename) 
    mfccs = librosa.feature.mfcc(y=librosa_audio3, sr=librosa_sample_rate3, n_mfcc=40)
    import librosa.display
    #spectogram
    librosa.display.specshow(mfccs, sr=librosa_sample_rate, x_axis='time')
    fig = plt.gcf()
    uri = convert_fig_to_uri(fig)
    return JsonResponse(uri, safe=False)

