from django.urls import path
from startup import views

urlpatterns = [
    path("", views.startup, name="startup"),
    path("login", views.login, name="login"),
    path("logout", views.logout, name="logout"),
    path("dashboard", views.upload_data, name="upload_data"),
    path("auditory_inspection", views.auditory_inspection, name="auditory_inspection"),
    path("visual_inspection", views.visual_inspection, name="visual_inspection"),
    path("original_waveform", views.original_waveform, name="original_waveform"),
    path("librosa_waveform", views.librosa_waveform, name="librosa_waveform"),
    path("spectogram", views.spectogram, name="spectogram"),
]